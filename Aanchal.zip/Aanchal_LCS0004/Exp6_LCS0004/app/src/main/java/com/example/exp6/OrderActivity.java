package com.example.exp6;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class OrderActivity extends AppCompatActivity {
    TextView res;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);
        res = findViewById(R.id.result);
        Intent intt = getIntent();
        String cakeFlavour = intt.getStringExtra("ITEM");
        String dated = intt.getStringExtra("DATE");
        String timed = intt.getStringExtra("TIME");
        res.setText("Your Order Placed Successfully."+"\nYour "+cakeFlavour+" cake will be delivered on"+dated+"\nat"+timed);
    }
}