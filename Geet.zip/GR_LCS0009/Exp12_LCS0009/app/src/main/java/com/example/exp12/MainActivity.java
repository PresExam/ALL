package com.example.exp12;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // Define constant IDs for menu items
    private static final int MENU_ITEM_1_ID = R.id.menu_item1;
    private static final int MENU_ITEM_2_ID = R.id.menu_item2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == MENU_ITEM_1_ID) {
            // Handle menu item 1 click
            menuItem1Clicked();
            return true;
        } else if (item.getItemId() == MENU_ITEM_2_ID) {
            // Handle menu item 2 click
            menuItem2Clicked();
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }


    private void menuItem1Clicked() {
        Toast.makeText(this, "Menu Item 1 clicked", Toast.LENGTH_SHORT).show();
        // Implement your action for menu item 1 click
    }

    private void menuItem2Clicked() {
        Toast.makeText(this, "Menu Item 2 clicked", Toast.LENGTH_SHORT).show();
        // Implement your action for menu item 2 click
    }
}
