package com.example.exp9;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
public class MainActivity extends AppCompatActivity {
    TextView tv;
    ProgressBar progress;
    BatteryReceiver BR;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv = findViewById(R.id.batteryText);
        progress = findViewById(R.id.progressBar);
    }
    public void checkBatteryPercentage(View view){
        BR = new BatteryReceiver(tv,progress);
        registerReceiver(BR,new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
    }
    @Override
    protected void onStop() {
        super.onStop();
        unregisterReceiver(BR);
    }
}
