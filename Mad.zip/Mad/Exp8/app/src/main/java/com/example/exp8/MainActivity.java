package com.example.exp8;

import androidx.appcompat.app.AppCompatActivity;
import android.app.Fragment;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {
    ListView list;
    String Stu[] = {"ABC","DEF","GHI","JKL"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        list = findViewById(R.id.studentList);
        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1,Stu);
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                DetailsFragment frag = (DetailsFragment)
                        getSupportFragmentManager().findFragmentById(R.id.fragmentPortion);
                frag.change(position);
            }
        });
    }
}
