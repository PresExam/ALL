package com.example.exp11;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.widget.TextView;
public class AeroplaneModeChangedEx extends BroadcastReceiver {
    TextView tview;
    AeroplaneModeChangedEx(TextView tv) {
        tview = tv;
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        Boolean isAirplaneModeEnabled = intent.getBooleanExtra("state", false);
        if (isAirplaneModeEnabled) {
            tview.setText("Aeroplane Mode ON");
            tview.setTextColor(Color.parseColor("#FF0000"));
        } else {
            tview.setText("Aeroplane Mode OFF");
            tview.setTextColor(Color.parseColor("#C8FF460C"));
        }
    }
}
